module.exports.appid = "amzn1.ask.skill.1454b72d-5b2b-44b5-8d7c-1023657cbe59";
module.exports.gapi = "AIzaSyClF1oblEyOcJyieku_GqZna_dbqGeCNX4";